package com.example.dailynotes

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- JSON / النسخ الاحتياطي ----------
fun notesToJson(list: List<Note>): String {
    val a = JSONArray()
    list.forEach {
        a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body)
            .put("date", it.date).put("pinned", it.pinned).put("category", it.category))
    }
    return JSONObject().put("app", "DailyNotes").put("version", 1)
        .put("exportedAt", System.currentTimeMillis()).put("notes", a).toString(2)
}

fun notesFromJson(text: String): List<Note> {
    val t = text.trim()
    val a = if (t.startsWith("[")) JSONArray(t) else JSONObject(t).getJSONArray("notes")
    return (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Note(o.getLong("id"), o.optString("title"), o.optString("body"),
            o.optLong("date", o.getLong("id")), o.optBoolean("pinned"),
            o.optString("category", categories[0]))
    }
}

// ---------- التذكير اليومي ----------
object Reminder {
    const val CHANNEL = "daily_reminder"
    private fun sp(c: Context) = c.getSharedPreferences("reminder", Context.MODE_PRIVATE)
    fun enabled(c: Context) = sp(c).getBoolean("on", false)
    fun hour(c: Context) = sp(c).getInt("h", 21)
    fun minute(c: Context) = sp(c).getInt("m", 0)
    fun save(c: Context, on: Boolean, h: Int, m: Int) =
        sp(c).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).apply()

    private fun pending(c: Context) = PendingIntent.getBroadcast(
        c, 1, Intent(c, ReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(c)); set(Calendar.MINUTE, minute(c))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending(c))
    }

    fun cancel(c: Context) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(c))
    }

    fun show(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "التذكير اليومي", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ملاحظاتي اليومية")
            .setContentText("حان وقت تدوين ملاحظات يومك")
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(100, n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Reminder.enabled(c)) return
        if (i.action != Intent.ACTION_BOOT_COMPLETED) Reminder.show(c)
        Reminder.schedule(c) // جدولة اليوم التالي
    }
}

// ---------- شاشة الإعدادات ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(notes: List<Note>, onImport: (List<Note>) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Reminder.enabled(ctx)) }
    var hour by remember { mutableStateOf(Reminder.hour(ctx)) }
    var minute by remember { mutableStateOf(Reminder.minute(ctx)) }
    var msg by remember { mutableStateOf("") }
    BackHandler(onBack = onBack)

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) msg = try {
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(notesToJson(notes).toByteArray()) }
            "تم حفظ ${notes.size} ملاحظة في النسخة الاحتياطية"
        } catch (e: Exception) { "فشل التصدير" }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) msg = try {
            val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val imported = notesFromJson(text)
            val merged = (notes.associateBy { it.id } + imported.associateBy { it.id }).values.toList()
            onImport(merged)
            "تم استيراد ${imported.size} ملاحظة (الإجمالي ${merged.size})"
        } catch (e: Exception) { "ملف غير صالح" }
    }

    fun apply(on: Boolean) {
        Reminder.save(ctx, on, hour, minute)
        if (on) Reminder.schedule(ctx) else Reminder.cancel(ctx)
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("الإعدادات") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "رجوع") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("التذكير اليومي", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تفعيل التذكير", Modifier.weight(1f))
                Switch(enabled, { on ->
                    enabled = on
                    if (on && Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
                        permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    apply(on)
                })
            }
            OutlinedButton(onClick = {
                TimePickerDialog(ctx, { _, h, m ->
                    hour = h; minute = m
                    Reminder.save(ctx, enabled, h, m)
                    if (enabled) Reminder.schedule(ctx)
                }, hour, minute, false).show()
            }, Modifier.fillMaxWidth()) {
                Text("وقت التذكير: " + String.format(Locale.US, "%02d:%02d", hour, minute))
            }

            HorizontalDivider()
            Text("النسخ الاحتياطي", style = MaterialTheme.typography.titleMedium)
            Button(onClick = {
                exportLauncher.launch("notes_backup_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".json")
            }, Modifier.fillMaxWidth()) { Text("تصدير نسخة احتياطية") }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) {
                Text("استيراد نسخة احتياطية (دمج)")
            }
            if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodyMedium)
            Text("عدد الملاحظات الحالية: ${notes.size}", style = MaterialTheme.typography.labelMedium)
        }
    }
}
