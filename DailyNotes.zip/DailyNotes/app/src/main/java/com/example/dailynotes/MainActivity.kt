package com.example.dailynotes

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Note(
    val id: Long, val title: String, val body: String,
    val date: Long, val pinned: Boolean, val category: String
)

val categories = listOf("يومية", "عمل", "أفكار", "مهام", "شخصي")

class NoteStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("notes", Context.MODE_PRIVATE)
    fun load(): List<Note> = try { notesFromJson(sp.getString("data", "[]")!!) } catch (e: Exception) { emptyList() }
    fun save(list: List<Note>) { sp.edit().putString("data", notesToJson(list)).apply() }
}

fun fmt(t: Long): String =
    SimpleDateFormat("EEEE d MMMM yyyy - hh:mm a", Locale("ar")).format(Date(t))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = NoteStore(this)
        if (Reminder.enabled(this)) Reminder.schedule(this)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { App(store) } }
            }
        }
    }
}

@Composable
fun App(store: NoteStore) {
    var notes by remember { mutableStateOf(store.load()) }
    var editing by remember { mutableStateOf<Note?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    fun commit(l: List<Note>) { notes = l; store.save(l) }

    if (showSettings) {
        SettingsScreen(notes, onImport = { commit(it) }, onBack = { showSettings = false })
        return
    }
    val e = editing
    if (e != null) {
        BackHandler { editing = null }
        Editor(
            note = e,
            onSave = { n ->
                commit(if (notes.any { it.id == n.id }) notes.map { if (it.id == n.id) n else it } else notes + n)
                editing = null
            },
            onDelete = { commit(notes.filter { it.id != e.id }); editing = null },
            onBack = { editing = null }
        )
    } else {
        NotesList(notes,
            onSettings = { showSettings = true },
            onAdd = {
                val now = System.currentTimeMillis()
                editing = Note(now, "", "", now, false, categories[0])
            },
            onOpen = { editing = it },
            onPin = { n -> commit(notes.map { if (it.id == n.id) it.copy(pinned = !it.pinned) else it }) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesList(notes: List<Note>, onAdd: () -> Unit, onOpen: (Note) -> Unit, onPin: (Note) -> Unit, onSettings: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<String?>(null) }
    val shown = notes
        .filter { filter == null || it.category == filter }
        .filter { query.isBlank() || it.title.contains(query, true) || it.body.contains(query, true) }
        .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.date })

    Scaffold(
        topBar = { TopAppBar(title = { Text("ملاحظاتي اليومية") }, actions = { IconButton(onSettings) { Icon(Icons.Default.Settings, "الإعدادات") } }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, "إضافة") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("بحث في الملاحظات") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth()
            )
            LazyRow(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(filter == null, { filter = null }, { Text("الكل") }) }
                items(categories) { c -> FilterChip(filter == c, { filter = if (filter == c) null else c }, { Text(c) }) }
            }
            Text("عدد الملاحظات: ${shown.size}", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Text("لا توجد ملاحظات بعد. اضغط + لإضافة أول ملاحظة")
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(shown, key = { it.id }) { n ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(n) }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(n.title.ifBlank { "بدون عنوان" }, style = MaterialTheme.typography.titleMedium)
                                Text(n.body, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Text("${n.category} • ${fmt(n.date)}", style = MaterialTheme.typography.labelSmall)
                            }
                            IconToggleButton(n.pinned, { onPin(n) }) {
                                Icon(if (n.pinned) Icons.Default.Star else Icons.Default.StarBorder, "تثبيت")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Editor(note: Note, onSave: (Note) -> Unit, onDelete: () -> Unit, onBack: () -> Unit) {
    var title by remember { mutableStateOf(note.title) }
    var body by remember { mutableStateOf(note.body) }
    var cat by remember { mutableStateOf(note.category) }
    var confirm by remember { mutableStateOf(false) }
    val canSave = title.isNotBlank() || body.isNotBlank()

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("ملاحظة") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "رجوع") } },
            actions = {
                IconButton({ confirm = true }) { Icon(Icons.Default.Delete, "حذف") }
                IconButton({ if (canSave) onSave(note.copy(title = title.trim(), body = body, category = cat, date = System.currentTimeMillis())) else onBack() }) {
                    Icon(Icons.Default.Check, "حفظ")
                }
            })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(title, { title = it }, label = { Text("العنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { c -> FilterChip(cat == c, { cat = c }, { Text(c) }) }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(body, { body = it }, label = { Text("اكتب ملاحظتك هنا...") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp))
            Spacer(Modifier.height(8.dp))
            Text("عدد الكلمات: ${body.trim().split(Regex("\\s+")).count { it.isNotBlank() }}", style = MaterialTheme.typography.labelSmall)
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("حذف الملاحظة؟") }, text = { Text("لا يمكن التراجع عن الحذف.") },
        confirmButton = { TextButton({ confirm = false; onDelete() }) { Text("حذف") } },
        dismissButton = { TextButton({ confirm = false }) { Text("إلغاء") } })
}
